
# Confiabiliza — Site de Lançamento

## Arquivos
- `index.html` — Landing page (Plano Empresarial 147 + Premium VIP 997), contador até 31/10, WhatsApp flutuante.
- `obrigado.html` — Página de entrega: botão **Acessar Planilha e Agente** (abre o Drive), iframe do **Agente ConfiaGPT**, botão "Voltar à Página Inicial".
- `Logo da Confiabiliza com Confiança.png` — Logo usada no topo e rodapé.

## Publicação rápida
1. Envie **index.html**, **obrigado.html** e a **logo** para a raiz do seu domínio (ex.: `www.gptreformatributaria.com.br`).
2. Se usar Netlify/Vercel:
   - Crie um novo site e suba estes arquivos.
   - A URL final será `https://seusite.netlify.app` (ou seu domínio configurado).
3. Verifique:
   - Botões dos planos: 
     - Empresarial → https://mpago.la/1oXf2wV
     - Premium → https://mpago.li/2Gp1od3
   - WhatsApp flutuante abre `+55 54 99176-0006`.

## Redirect pós-pagamento (Mercado Pago)
Configure a URL de retorno/redirect do checkout para:
- `https://www.gptreformatributaria.com.br/obrigado.html`

## Dicas
- Mantenha `Logo da Confiabiliza com Confiança.png` no mesmo diretório dos HTMLs.
- Para trocar textos/valores, edite diretamente os HTMLs (procure por “R$ 147”, “R$ 997” e “31/10”).
- Para rastreamento, cole seu Pixel/GA no `<head>` do `index.html`.

Bom lançamento! 🚀
